[OPTIONAL] Create & activate virtual environment:

    $ pip install virtualenv
    $ virtualenv env
    $ source ./env/bin/activate

Install Requirements:

    $ pip install -r requirements.txt

Start notebook server
    $ jupyter notebook